# Wikipedia2LaTeX
## _Create fancy pdf LaTeX documents from wikipedia articles_

## Installation

Dillinger requires [Node.js](https://nodejs.org/) v10+ to run.

Install the dependencies and devDependencies and start the server.

```sh
cd dillinger
npm i
node app
```

## License

MIT


